<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{nextpay}default>nextpay_6f45efeb44e5d8cfe1e14ce4467f1f67'] = 'افزونه پرداخت نکست پی';
$_MODULE['<{nextpay}default>nextpay_909b1fcb6b37b6a330444235bfc2462c'] = ' پرداخت آنلاین با درگاه امن نکست پی';
$_MODULE['<{nextpay}default>nextpay_69a1a3ad8dd5da6db3c4da838a0cf9c7'] = 'آیا برای پاک کردن اطلاعات مطمئن هستید؟';
$_MODULE['<{nextpay}default>nextpay_e2d93539acef2afbbadf8542351fb2b4'] = 'استفاده از ارز برای این ماژول غیر فعال هست.';
$_MODULE['<{nextpay}default>nextpay_6577035ab365dbb6b8f79829d4d29748'] = 'شما برای استفاده از درگاه امن نکست پی می بایست کلید مجوزدهی درگاه خود را در تنظیمات ماژول وارد کنید.';
$_MODULE['<{nextpay}default>nextpay_c888438d14855d7d96a2724ee9c306bd'] = 'تنظیمات دخیره شد.';
$_MODULE['<{nextpay}default>nextpay_b4740c9e4dd0751ea682fd81d627dee2'] = 'کلید مجوزدهی درگاه خود را وارد نمایید :';
$_MODULE['<{nextpay}default>nextpay_17857bb7e0e4a22fa99900af223a03f9'] = 'دخیره کن!';
$_MODULE['<{nextpay}default>nextpay_6585d9032a8dc4539e89237937549739'] = 'مشکلی وجود دارد!';
$_MODULE['<{nextpay}default>nextpay_2ea624d388b73c5ad7976bbb9d758a4f'] = 'در حال انتقال ...';
$_MODULE['<{nextpay}default>zppayment_a9950f28d15992aed5045f5818cdb361'] = ' پرداخت آنلاین با درگاه امن نکست پی';
